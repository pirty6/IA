import sys
from copy import deepcopy

def get_ancestors(query, table, ancestors, fixed):
    if(len(fixed) == 0):
        for element in query:
            fixed.append(element)
    if(len(query) == 0):
        return ancestors
    else:
        parents = deepcopy(table[query[0]]['ancestors'])
        for parent in parents:
            if (parent not in ancestors and parent not in fixed):
                ancestors.append(parent)
                if(parent not in query):
                    query.append(parent)
        return get_ancestors(query[1:], table, ancestors, fixed)

def half_true_half_false(probabilities, start, end, combinations, sign, index):
    if index < len(probabilities):
        letter = deepcopy(probabilities[index])
        for j in range (start,end):
            combinations[j][index]= sign + letter
            half_true_half_false(probabilities, start, start + int((end-start)/2), combinations, '+', index+1)
            half_true_half_false(probabilities, start + int((end-start)/2), end, combinations, '-', index+1)

def get_combinations(probabilities):
    num_combinations = 2 ** len(probabilities)
    combinations=[]
    for i in range (0,num_combinations):
        combinations.append(deepcopy(probabilities))
    half_true_half_false(probabilities, 0, int(num_combinations/2), combinations, '+', 0)
    half_true_half_false(probabilities, int(num_combinations/2), num_combinations, combinations, '-', 0)
    return combinations

def get_probability(table, elem):
    value = 1.0
    for item in elem:
        node = table[item[1:]]
        condition = deepcopy(item)
        expression = []
        for parent in node['ancestors']:
            for element in elem:
                if(parent == element[1:]):
                    expression.append(element)
        expression = [condition] + expression
        for probability in node['probabilities']:
            if(probability[0:-1] == expression):
                value = value * probability[-1]
    return value

# Read input
data = sys.stdin.readlines()
# Get nodes
nodes = data[0].rstrip("\n").split(",")
table = {}
# Create dictionary for all the probabilities and the ancestors
for i in range(0, len(nodes)):
    table[nodes[i]] = {'probabilities': [], 'ancestors': []}
# Get the probabilities from the given data
no_probabilities = int(data[1].rstrip("\n"))
probabilities = []
# Add the probabilities to the table
for i in range(2, no_probabilities + 2):
    probability = data[i].rstrip("\n").replace('|',' ').replace(',',' ').replace('=',' ').split()
    key = probability[0][1:]
    probability[len(probability) - 1] = float(probability[len(probability) - 1])
    table[key]['probabilities'].append(probability)
# Get queries
no_queries = int(data[no_probabilities + 2].rstrip("\n"))
queries = []
for i in range(no_probabilities + 3, no_queries + no_probabilities + 3):
    query = data[i].rstrip("\n")
    conditions = []
    if "|" in query:
        conditions = query.split('|')[1].split(',')
    query = [query.replace('|', ',').split(','), conditions]
    queries.append(query)
# Get all the probabilities and add them to the dictionary
for item in table:
    probabilities = table[item]['probabilities']
    for probability in probabilities:
        sign = probability[0][0]
        if(sign == '+'):
            new_sign = '-'
        else:
            new_sign = '+'
        new_probability = deepcopy(probability)
        new_probability[0] = new_sign + probability[0][1:]
        new_probability[len(new_probability) - 1] = round(1 - probability[len(new_probability) - 1], 7)
        if new_probability not in probabilities:
            probabilities.append(new_probability)
    # Get the ancestors of the nodes
    ancestors = table[item]['probabilities'][0][1:len(table[item]['probabilities'][0])-1]
    for i in range(0, len(ancestors)):
        ancestors[i] = ancestors[i][1:]
    table[item]['ancestors'] = ancestors
# Get result from the queries
for query in queries:
    list_conditions = []
    for q in query[0]:
        list_conditions.append(q[1:])
    ancestors_numerator = get_ancestors(list_conditions, table, [], [])
    combinations_numerator = get_combinations(ancestors_numerator)
    numerator = 0
    for elem in combinations_numerator:
        elem = query[0] + elem
        numerator += get_probability(table, elem)
    if len(query[1]) > 0:
        list_conditions = []
        for q in query[1]:
            list_conditions.append(q[1:])
        ancestors_denominator = get_ancestors(list_conditions, table, [], [])
        combinations_denominator = get_combinations(ancestors_denominator)
        denominator = 0
        for item in combinations_denominator:
            item = query[1] + item
            denominator += get_probability(table, item)
        print(round(numerator/denominator, 7))
    else:
        print(round(numerator,7))
